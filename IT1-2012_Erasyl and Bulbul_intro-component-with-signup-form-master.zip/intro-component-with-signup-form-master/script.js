const form = document.getElementById('form');
form.addEventListener('submit', e => {
    e.preventDefault();
    const fname = form['fname'].value;
    const lname = form['lname'].value;
    const email = form['email'].value;
    const password = form['password'].value;

    var fristName = fname.value.trim();
    var lastName = lname.value.trim();
    var emailValue = email.value.trim();
    var passwordValue = password.value.trim();


    if (fname === '') {
        addError(fname, 'First Name cannot be empty')
        addError('fname')
    } else {
        removeError('fname')
    }
    if (lname === '') {
        addError(lname, 'Last Name cannot be empty')
    } else {
        removeError('lname')
    }
    if (email === '') {
        addError(email, 'Email cannot be empty')
    } else if (!isValid(email)) {
        addError(email, 'Email is not valid')
    } else {
        removeError('email')
    }
    if (password === '') {
        addError(password, 'Password cannot be empty')
    } else {
        removeError('password')
    }
})
function addError(field, message) {
    const formControl = form[field].parentNode;
    const span = formControl.querySelector('span')
    span.innerText = message
    formControl.classList.add('error');
}
function removeError(field) {
    const formControl = form[field].parentNode;
    const span = formControl.querySelector('span')
    span.innerText = message
    formControl.classList.remove('error');
}
function isValid(email) {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}
